echo "Welcome to Meowtop"

echo "Installing files..."
sudo mkdir /usr/bin/Meowtop
sudo cp Meowtop.desktop /usr/share/xsessions/
sudo cp Meowtop /usr/bin/Meowtop
sudo cp start-meowtop /usr/bin/
sudo cp meowtop-binary /usr/libexec/

echo "Done! please logout and select Prism 3 to complete installation"
